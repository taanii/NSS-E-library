<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.1/jquery.min.js  " />
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/gh/kmlpandey77/bootnavbar/css/bootnavbar.css"/>
    <link rel="stylesheet" href="css/nav.css" />
</head>


<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-cerulean d-print" id="navbar">

        <a class="navbar-brand" id="logo_n_brandname" href="#"><img src="images/new_logo.png"
                id="logo" />ज्ञानभंडार</a>

        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent"
            aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>


        <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav ml-auto">
                <li class="nav-item active mar">
                    <a class="nav-link" href="#">Home <span class="sr-only">(current)</span></a>
                </li>

                <li class="nav-item dropdown active mar">
                    <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button"
                        data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        Library Section
                    </a>
                    <ul class="dropdown-menu">
                        <li><a class="dropdown-item" href="#">Audio Stories</a></li>

                        <li class="nav-link dropdown">
                            <a href="#" class="dropdown-item dropdown-toggle" data-toggle="dropdown">
                                Books
                            </a>
                            <ul class="dropdown-menu">
                                <li><a class="dropdown-item" href="#">Educational Books</a></li>
                                <li><a class="dropdown-item" href="#">Story books</a></li>
                                <li><a class="dropdown-item" href="#">Picture books</a></li>

                            </ul>
                        </li>
                        
                        <li><a class="dropdown-item" href="#">Poems</a></li>
                    </ul>
                </li>
                <li class="nav-item active  mar">
                    <a class="nav-link" href="#">About us</a>
                </li>
                </li>
            </ul>
        </div>

    </nav>
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
    <script src="https://cdn.jsdelivr.net/gh/kmlpandey77/bootnavbar/js/bootnavbar.js"></script>
    <script>
        $('navbar').bootnavbar();
    </script>
</body>

</html>